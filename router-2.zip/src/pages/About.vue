<template>
    <Pricing />
</template>
<script>
import Pricing from '@/components/Pricing.vue'
export default {
    components: {
        Pricing
    }
}
</script>
