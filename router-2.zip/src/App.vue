<template>
  <Home />
</template>
<script>
import Home from '@/pages/Home.vue'
export default {
  components: {
    Home
  }
}
</script>